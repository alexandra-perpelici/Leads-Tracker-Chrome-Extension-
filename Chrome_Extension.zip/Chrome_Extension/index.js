
let myLeads = [];
const inputEl = document.getElementById("input-el");

const inputbtn = document.getElementById("input-btn");
const deletebtn = document.getElementById("delete-btn");
const savetabbtn = document.getElementById("savetab-btn");

const ulEl =document.getElementById("ul-el");

const leadsFromLocalStorage = JSON.parse( localStorage.getItem("myLeads")) // use localStorage to remember the previous inputs after refreshing the page;
//get the value from localStorage and transform it into an array with parse()


if(leadsFromLocalStorage) // if we have something into the localStorage => put it into the leads array
{
    myLeads = leadsFromLocalStorage;
    renderLeads(myLeads);
}


savetabbtn.addEventListener("click", function(){
 // get the current tab from chrome in tabs 
  chrome.tabs.query({active: true, currentWindow: true}, function (tabs){
  myLeads.push(tabs[0].url);
  localStorage.setItem("myLeads",JSON.stringify(myLeads));
  renderLeads(myLeads);

  })

})

deletebtn.addEventListener("dblclick", function()
{   localStorage.clear();
    myLeads = [];
    renderLeads(myLeads);
  
})

inputbtn.addEventListener("click",function(){

    myLeads.push(inputEl.value); // save the input into the array
    inputEl.value = "";// clear the input bar after hitting save button
    localStorage.setItem("myLeads", JSON.stringify(myLeads));// set the value of the localStorage
    // "myLeads" = the key, myLeads= the content that was transformed into a string because localStorage only works with strings
    renderLeads(myLeads); // display the saved input in the list

})

 
function renderLeads (leads) // display the leads in the browser
{
        let listItems = "";

    for (let i = 0; i<leads.length;i++)
    {

    listItems += `
    <li>
    <a target = '_blank' href = ' ${leads[i]}'> 
    ${leads[i]} 
    </a>
    </li>
    `
    } // using template strings to display the list : use `` to make it a string + use ${ } for variables

    ulEl.innerHTML = listItems;
}
